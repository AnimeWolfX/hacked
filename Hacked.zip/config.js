exports.PREFIX = "n";
exports.OWNER_ID = "792037342771675187";
exports.Owner_Name = "TheFreshS#8736";